/*
 * st7789.c
 *
 * For ST7789 170*320 display module
 *
 * Created:		09.04.2025
 * Author:		HTTPS://R9OFG.RU
 *
 * Release:		1.1
 *
 * Modified:	15.07.2025
 *
 */ 

#include "st7789.h"
#include "font_tahoma_8_en_ru.h"
#include "font_terminus_15_digi.h"

uint16_t CurrentWidth = ST7789_WIDTH;	//Текущая ширина
uint16_t CurrentHeight = ST7789_HEIGHT;	//Текущая высота
uint16_t StartWidthConstant = (240 - ST7789_WIDTH) / 2;
uint16_t EndWidthConstant = (240 - ST7789_WIDTH - 1) / 2;
uint16_t StartHeightConstant = 0;
uint16_t EndHeightConstant = 0;
uint8_t CurrentRotation = ST7789_ROTATE_0;

volatile uint8_t UseDMA = 0;			//Флаг использования DMA
volatile uint8_t ST7789_SPI_Ready = 1;	//Флаг готовности SPI
static uint8_t BufferDMA[1024];			//Буфер под DMA (размер кратен 2)

//Функция отправки команды дисплею
void ST7789_SendCommand(uint8_t command)
{
    ST7789_CS_LOW();
    ST7789_DC_LOW(); //Команда
    HAL_SPI_Transmit(&hspi1, &command, 1, HAL_MAX_DELAY);
    ST7789_CS_HIGH();
}

//Функция отправки данных дисплею
void ST7789_SendData(uint8_t data)
{
    ST7789_CS_LOW();
    ST7789_DC_HIGH(); //Данные
    HAL_SPI_Transmit(&hspi1, &data, 1, HAL_MAX_DELAY);
    ST7789_CS_HIGH();
}

//Функция отправки данных дисплею с использованием DMA
void ST7789_SendData_DMA(uint8_t *data, uint32_t size)
{
    while (!ST7789_SPI_Ready);  //Ждем готовности
    ST7789_SPI_Ready = 0;
    ST7789_DC_HIGH();           //Данные
    ST7789_CS_LOW();
    HAL_SPI_Transmit_DMA(&hspi1, data, size);
}

//Функция поворота экрана
void ST7789_SetRotation(char rotation)
{
	CurrentRotation = rotation;

	ST7789_SendCommand(ST7789_MADCTL);
    ST7789_SendData(rotation | ST7789_RGB);

    if (rotation == ST7789_ROTATE_90 || rotation == ST7789_ROTATE_270)
	{
        CurrentWidth = ST7789_HEIGHT;
        CurrentHeight = ST7789_WIDTH;
        StartWidthConstant = (320 - CurrentWidth) / 2;
        EndWidthConstant = (320 - CurrentWidth - 1) / 2;
        StartHeightConstant = (240 - CurrentHeight) / 2;
        EndHeightConstant = (240 - CurrentHeight - 1) / 2;
    } else {
        CurrentWidth = ST7789_WIDTH;
        CurrentHeight = ST7789_HEIGHT;
        StartWidthConstant = (240 - CurrentWidth) / 2;
        EndWidthConstant = (240 - CurrentWidth - 1) / 2;
        StartHeightConstant = 0;
        EndHeightConstant = 0;
    }
}

// Функция установки области для отрисовки
void ST7789_SetRegion(uint16_t x, uint16_t y, uint16_t width, uint16_t height)
{
    x = StartWidthConstant + x;
    width = EndWidthConstant + width;
    y = StartHeightConstant + y;
    height = EndHeightConstant + height;

    ST7789_SendCommand(ST7789_CASET);
    ST7789_SendData(x >> 8);
    ST7789_SendData(x & 0xFF);
    ST7789_SendData(width >> 8);
    ST7789_SendData(width & 0xFF);

    ST7789_SendCommand(ST7789_RASET);
    ST7789_SendData(y >> 8);
    ST7789_SendData(y & 0xFF);
    ST7789_SendData(height >> 8);
    ST7789_SendData(height & 0xFF);
}

// Функция заливки экрана выбранным цветом
void ST7789_FillScreen(uint16_t color, uint16_t cntPxl)
{
	ST7789_SetRegion(0, 0, CurrentWidth, CurrentHeight);
	ST7789_SendCommand(ST7789_RAMWR);

	if(!UseDMA)
	{
		//без DMA
		while (cntPxl--)
		{
			ST7789_SendData(color >> 8);
			ST7789_SendData(color & 0xFF);
		}
	}
	else if(UseDMA)
	{
		//с DMA
		uint32_t size = cntPxl * 2;
		for (int i = 0; i < sizeof(BufferDMA); i += 2) {
			BufferDMA[i] = color >> 8;
			BufferDMA[i+1] = color & 0xFF;
		}

		while (size)
		{
			uint16_t chunk = (size > sizeof(BufferDMA)) ? sizeof(BufferDMA) : size;
			ST7789_SendData_DMA(BufferDMA, chunk);
			while (!ST7789_SPI_Ready);  //ждем окончания передачи
			size -= chunk;
		}
	}
}

//Функция инициализации дисплея
void ST7789_Init()
{
	BLK_OFF();

	ST7789_RST_LOW();
    HAL_Delay(10);
    ST7789_RST_HIGH();
    HAL_Delay(120);

    ST7789_SendCommand(ST7789_SWRESET);
    HAL_Delay(200);

    ST7789_SendCommand(ST7789_SLPOUT);
    HAL_Delay(120);

    ST7789_SendCommand(ST7789_COLMOD);
    ST7789_SendData(0x55);
    HAL_Delay(10);

    ST7789_SendCommand(ST7789_INVON);
    ST7789_SendCommand(ST7789_DISPON);
    HAL_Delay(10);

    ST7789_SetRotation(ST7789_ROTATE_270);
    ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
}

//Функция вывода одного пикселя выбранным цветом
void ST7789_DrawPixel(uint16_t x, uint16_t y, uint16_t color)
{
    if (x >= CurrentWidth || y >= CurrentHeight) return;

    ST7789_SetRegion(x, y, x, y);
    ST7789_SendCommand(ST7789_RAMWR);
    ST7789_SendData(color >> 8);
    ST7789_SendData(color & 0xFF);
}

/* Графические примитивы ==================================================================================== */

//Функция вывода линии
void ST7789_DrawLine(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint16_t color)
{
	//Проверка границ
	if (x > CurrentWidth || y > CurrentHeight || width> CurrentWidth || height > CurrentHeight) {return; /* Выход за границы, прерываем */}

	int16_t dx = abs(width - x);		//Разница по оси X
	int16_t dy = -abs(height - y);		//Разница по оси Y (отрицательная для корректного направления)
	int16_t sx = (x < width) ? 1 : -1;	//Направление движения по X
	int16_t sy = (y < height) ? 1 : -1;	//Направление движения по Y
	int16_t err = dx + dy;				//Ошибка для алгоритма Брезенхэма

	while (1)
	{
		//Рисуем пиксель в текущей точке
		ST7789_DrawPixel(x, y, color);
		//Если достигли конечной точки, завершаем цикл
		if (x == width && y == height) break;
		int16_t e2 = 2 * err;
		//Корректировка ошибки и движение по X или Y
		if (e2 >= dy) {err += dy; x += sx;}
		if (e2 <= dx) {err += dx; y += sy;}
	}
}

//Функция вывода пустотелого прямоугольника выбранным цветом
void ST7789_DrawRectangle(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint16_t color)
{
	//Проверка границ
	if (x > CurrentWidth - 1 || y > CurrentHeight - 1 || width > CurrentWidth - 1 || height > CurrentHeight - 1) {return; /* Выход за границы, прерываем */}

	//Рисуем верхнюю и нижнюю границы
	ST7789_DrawLine(x, y, width, y, color);
	ST7789_DrawLine(x, height, width, height, color);

	//Рисуем левую и правую границы
	ST7789_DrawLine(x, y, x, height, color);
	ST7789_DrawLine(width, y, width, height, color);
}

//Функция вывода закрашенного прямоугольника выбранным цветом
void ST7789_DrawFillRectangle(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint16_t color)
{
	//Проверка границ
	if (x > CurrentWidth - 1 || y > CurrentHeight - 1 || width > CurrentWidth - 1 || height > CurrentHeight - 1) {return; /* Выход за границы, прерываем */}

	//Установка области для отрисовки, регион по размеру прямоугольника
	ST7789_SetRegion(x, y, width, height);
	//Запись данных в RAM дисплея
	ST7789_SendCommand(ST7789_RAMWR);
	uint16_t cntPxl = width * height;

	if(!UseDMA)
	{
		while(cntPxl--)
		{
			ST7789_SendData(color >> 8);	//Старший байт цвета
			ST7789_SendData(color & 0xFF);	//Младший байт цвета
		}
	}
	else if(UseDMA)
	{
		uint32_t totalPixels = width * height;
		uint32_t maxPixelsPerTransfer = sizeof(BufferDMA) / 2;

		//Заполнение буфера цветом
		for (uint32_t i = 0; i < maxPixelsPerTransfer; i++)
		{
			BufferDMA[i * 2]     = color >> 8;
			BufferDMA[i * 2 + 1] = color & 0xFF;
		}

		//Отправка данными по частям
		while (totalPixels > 0)
		{
			uint32_t count = (totalPixels > maxPixelsPerTransfer) ? maxPixelsPerTransfer : totalPixels;
			ST7789_SendData_DMA(BufferDMA, count * 2);
			while (!ST7789_SPI_Ready);
			totalPixels -= count;
		}
	}
}

//Функция вывода пустотелого круга выбранным цветом
void ST7789_DrawCircle(uint16_t x, uint16_t y, uint16_t radius, uint16_t color)
{
	//Проверка границ
	if (x > CurrentWidth || y > CurrentHeight || (int8_t)(x - radius) < 0 || x + radius > CurrentWidth
	|| (int8_t)(y - radius) < 0 || y + radius > CurrentHeight) {return; /* Выход за границы, прерываем */}

	int16_t f = 1 - (int)radius;
	int16_t ddF_x = 1;
	int16_t ddF_y = -2 * (int)radius;
	int16_t x_0 = 0;

	ST7789_DrawPixel(x, y + radius, color); ST7789_DrawPixel(x, y - radius, color);
	ST7789_DrawPixel(x + radius, y, color); ST7789_DrawPixel(x - radius, y, color);

	int16_t y_0 = radius;
	while (x_0 < y_0)
	{
		if (f >= 0) { y_0--; ddF_y += 2; f += ddF_y; }
		x_0++; ddF_x += 2; f += ddF_x;

		ST7789_DrawPixel(x + x_0, y + y_0, color); ST7789_DrawPixel(x - x_0, y + y_0, color);
		ST7789_DrawPixel(x + x_0, y - y_0, color); ST7789_DrawPixel(x - x_0, y - y_0, color);
		ST7789_DrawPixel(x + y_0, y + x_0, color); ST7789_DrawPixel(x - y_0, y + x_0, color);
		ST7789_DrawPixel(x + y_0, y - x_0, color); ST7789_DrawPixel(x - y_0, y - x_0, color);
	}
}

//Функция вывода закрашенного круга выбранным цветом
void ST7789_DrawFillCircle(uint16_t x, uint16_t y, uint16_t radius, uint16_t color)
{
	//Проверка границ
	if (x > CurrentWidth || y > CurrentHeight || (int8_t)(x - radius) < 0 || x + radius > CurrentWidth
	|| (int8_t)(y - radius) < 0 || y + radius > CurrentHeight) {return; /* Выход за границы, прерываем */}

	int16_t f = 1 - (int16_t)radius;
	int16_t ddF_x = 1;
	int16_t ddF_y = -2 * (int16_t)radius;
	int16_t xx = 0;
	int16_t yy = radius;

	// Закрашиваем начальные горизонтальные линии
	ST7789_DrawLine(x - radius, y, x + radius, y, color); //Горизонтальная линия через центр

	while (xx < yy)
	{
		if (f >= 0) { yy--; ddF_y += 2; f += ddF_y; }
		xx++; ddF_x += 2; f += ddF_x;

		//Закрашиваем горизонтальные линии между симметричными точками
		ST7789_DrawLine(x - xx, y + yy, x + xx, y + yy, color); //Нижняя часть
		ST7789_DrawLine(x - xx, y - yy, x + xx, y - yy, color); //Верхняя часть
		ST7789_DrawLine(x - yy, y + xx, x + yy, y + xx, color); //Правая нижняя часть
		ST7789_DrawLine(x - yy, y - xx, x + yy, y - xx, color); //Правая верхняя часть
	}
}

//Функция вывода горизонтальной линии через DMA
void ST7789_DrawHorizontalLine_DMA(uint16_t x, uint16_t y, uint16_t length, uint16_t color)
{
    if (x + length > CurrentWidth || y >= CurrentHeight || length == 0) return;

    ST7789_SetRegion(x, y, x + length - 1, y);
    ST7789_SendCommand(ST7789_RAMWR);

    uint32_t size = length * 2;
    if (size > sizeof(BufferDMA)) size = sizeof(BufferDMA);

    for (uint32_t i = 0; i < size; i += 2)
    {
        BufferDMA[i]     = color >> 8;
        BufferDMA[i + 1] = color & 0xFF;
    }

    ST7789_SendData_DMA(BufferDMA, size);
    while (!ST7789_SPI_Ready);
}

//Функция вывода закрашенного круга выбранным цветом через DMA
void ST7789_DrawFillCircle_DMA(uint16_t x, uint16_t y, uint16_t radius, uint16_t color)
{
    if (x > CurrentWidth || y > CurrentHeight || (int16_t)(x - radius) < 0 || x + radius > CurrentWidth
     || (int16_t)(y - radius) < 0 || y + radius > CurrentHeight) return;

    int16_t f = 1 - (int16_t)radius;
    int16_t ddF_x = 1;
    int16_t ddF_y = -2 * (int16_t)radius;
    int16_t xx = 0;
    int16_t yy = radius;

    // Центральная горизонтальная линия
    ST7789_DrawHorizontalLine_DMA(x - radius, y, 2 * radius + 1, color);

    while (xx < yy)
    {
        if (f >= 0) { yy--; ddF_y += 2; f += ddF_y; }
        xx++; ddF_x += 2; f += ddF_x;

        // Четыре горизонтальные линии
        ST7789_DrawHorizontalLine_DMA(x - xx, y + yy, 2 * xx + 1, color);
        ST7789_DrawHorizontalLine_DMA(x - xx, y - yy, 2 * xx + 1, color);
        ST7789_DrawHorizontalLine_DMA(x - yy, y + xx, 2 * yy + 1, color);
        ST7789_DrawHorizontalLine_DMA(x - yy, y - xx, 2 * yy + 1, color);
    }
}

/* Шрифты =================================================================================================== */

//Функция вывода символа однобайтового шрифта с масштабированием
void ST7789_DrawCharOneByteFonts(uint16_t xPos, uint16_t yPos, char sym, uint16_t colorCh, uint16_t colorBk, uint8_t scale)
{
    if ((sym < 32) || (sym > 191) || (scale == 0)) return;

    uint8_t widthCh = font_tahoma_8[((sym - 0x20) * (FONT_TAHOMA_8_CHAR_HEIGHT + 1))] + 1;

    for (uint8_t y = 0; y < FONT_TAHOMA_8_CHAR_HEIGHT; y++)
	{
        for (uint8_t x = 0; x < widthCh; x++)
		{
            uint8_t bit = font_tahoma_8[((sym - 0x20) * (FONT_TAHOMA_8_CHAR_HEIGHT + 1)) + 1 + y] & (0x80 >> x);

            for (uint8_t sy = 0; sy < scale; sy++)
			{
                for (uint8_t sx = 0; sx < scale; sx++)
				{
                    ST7789_DrawPixel(xPos + x * scale + sx, yPos + y * scale + sy, bit ? colorCh : colorBk);
                }
            }
        }
    }
}

//Функция вывода символа однобайтового шрифта с масштабированием через DMA
void ST7789_DrawCharOneByteFonts_DMA(uint16_t xPos, uint16_t yPos, char sym, uint16_t colorCh, uint16_t colorBk, uint8_t scale)
{
    if ((sym < 32) || (sym > 191) || (scale == 0)) return;

    uint8_t widthCh = font_tahoma_8[((sym - 0x20) * (FONT_TAHOMA_8_CHAR_HEIGHT + 1))] + 1;
    uint8_t charHeight = FONT_TAHOMA_8_CHAR_HEIGHT;

    uint16_t widthPx = widthCh * scale;
    uint16_t heightPx = charHeight * scale;

    //Установка области
    if (CurrentRotation == ST7789_ROTATE_0 || CurrentRotation == ST7789_ROTATE_180)
    {
    	ST7789_SetRegion(xPos, yPos, xPos + widthPx, yPos + heightPx);
    }
    else if (CurrentRotation == ST7789_ROTATE_90 || CurrentRotation == ST7789_ROTATE_270)
    {
    	ST7789_SetRegion(xPos, yPos, xPos + widthPx - 1, yPos + heightPx - 1);
    }

    ST7789_SendCommand(ST7789_RAMWR);

    //Подготовка буфера
    uint32_t maxPx = sizeof(BufferDMA) / 2;

    uint32_t pxIndex = 0;

    for (uint8_t y = 0; y < charHeight; y++)
    {
        for (uint8_t sy = 0; sy < scale; sy++)
        {
            for (uint8_t x = 0; x < widthCh; x++)
            {
                uint8_t bit = font_tahoma_8[((sym - 0x20) * (FONT_TAHOMA_8_CHAR_HEIGHT + 1)) + 1 + y] & (0x80 >> x);

                for (uint8_t sx = 0; sx < scale; sx++)
                {
                    uint16_t color = bit ? colorCh : colorBk;

                    BufferDMA[pxIndex * 2]     = color >> 8;
                    BufferDMA[pxIndex * 2 + 1] = color & 0xFF;
                    pxIndex++;

                    //Если буфер заполнен — отправляем
                    if (pxIndex >= maxPx)
                    {
                        ST7789_SendData_DMA(BufferDMA, pxIndex * 2);
                        while (!ST7789_SPI_Ready);
                        pxIndex = 0;
                    }
                }
            }
        }
    }

    //Отправка оставшихся данных
    if (pxIndex > 0)
    {
        ST7789_SendData_DMA(BufferDMA, pxIndex * 2);
        while (!ST7789_SPI_Ready);
    }
}

//Функция вывода строки однобайтовым шрифтом
void ST7789_DrawStringOneByteFonts(uint16_t xPos, uint16_t yPos, char *str, uint16_t colorCh, uint16_t colorBk, uint8_t scale)
{
    uint16_t currentX = xPos;

    while (*str)
	{
    	if(!UseDMA)
    	{
    		ST7789_DrawCharOneByteFonts(currentX, yPos, *str, colorCh, colorBk, scale);
    	}
    	else if(UseDMA)
    	{
    		ST7789_DrawCharOneByteFonts_DMA(currentX, yPos, *str, colorCh, colorBk, scale);
    	}
        uint8_t widthCh = font_tahoma_8[((*str - 0x20) * (FONT_TAHOMA_8_CHAR_HEIGHT + 1))] + 1;
        currentX += widthCh * scale;
        str++;
    }
}

//Функция вывода символа двухбайтового шрифта с масштабированием
void ST7789_DrawCharTwoByteFonts(uint16_t xPos, uint16_t yPos, char sym, uint16_t colorCh, uint16_t colorBk, uint8_t scale)
{
	if ((sym < 48) || (sym > 57) || (scale == 0)) return;

    sym = (sym - 48) * 15;

    for (uint8_t y = 0; y < FONT_TERMINUS_10X15__CHAR_HEIGHT; y++)
	{
        for (uint8_t x = 0; x < 8; x++)
		{
            uint8_t bit = font_terminus_10x15_digi[(sym + y) * 2 + 1] >> (7 - x) & 0x01;

            if (x > 5)
			{
                for (uint8_t sy = 0; sy < scale; sy++)
				{
                    for (uint8_t sx = 0; sx < scale; sx++)
					{
                        ST7789_DrawPixel(xPos + (x - 6) * scale + sx, yPos + y * scale + sy, bit ? colorCh : colorBk);
                    }
                }
            }

            bit = font_terminus_10x15_digi[(sym + y) * 2] >> (7 - x) & 0x01;

            for (uint8_t sy = 0; sy < scale; sy++)
			{
                for (uint8_t sx = 0; sx < scale; sx++)
				{
                    ST7789_DrawPixel(xPos + (x + 2) * scale + sx, yPos + y * scale + sy, bit ? colorCh : colorBk);
                }
            }
        }
    }
}

// Функция вывода символа двухбайтового шрифта с масштабированием через DMA
void ST7789_DrawCharTwoByteFonts_DMA(uint16_t xPos, uint16_t yPos, char sym, uint16_t colorCh, uint16_t colorBk, uint8_t scale)
{
    if ((sym < 48) || (sym > 57) || (scale == 0)) return;

    uint16_t charIndex = (sym - 48) * 15;
    const uint8_t charWidth = 10;
    const uint8_t charHeight = FONT_TERMINUS_10X15__CHAR_HEIGHT;

    uint16_t widthPx = charWidth * scale;
    uint16_t heightPx = charHeight * scale;

    if (CurrentRotation == ST7789_ROTATE_0 || CurrentRotation == ST7789_ROTATE_180)
	{
		ST7789_SetRegion(xPos, yPos, xPos + widthPx, yPos + heightPx);
	}
	else if (CurrentRotation == ST7789_ROTATE_90 || CurrentRotation == ST7789_ROTATE_270)
	{
		ST7789_SetRegion(xPos, yPos, xPos + widthPx - 1, yPos + heightPx - 1);
	}

    ST7789_SendCommand(ST7789_RAMWR);

    uint32_t pxIndex = 0;
    const uint32_t maxPx = sizeof(BufferDMA) / 2;

    for (uint8_t y = 0; y < charHeight; y++)
    {
        uint8_t byte0 = font_terminus_10x15_digi[(charIndex + y) * 2];
        uint8_t byte1 = font_terminus_10x15_digi[(charIndex + y) * 2 + 1];

        for (uint8_t sy = 0; sy < scale; sy++)
        {
            for (uint8_t col = 0; col < charWidth; col++)
            {
                uint8_t bit;
                if (col < 2)
                    bit = (byte1 >> (1 - col)) & 0x01;
                else
                    bit = (byte0 >> (9 - col)) & 0x01;

                uint16_t color = bit ? colorCh : colorBk;

                for (uint8_t sx = 0; sx < scale; sx++)
                {
                    BufferDMA[pxIndex * 2]     = color >> 8;
                    BufferDMA[pxIndex * 2 + 1] = color & 0xFF;
                    pxIndex++;

                    if (pxIndex >= maxPx)
                    {
                        ST7789_SendData_DMA(BufferDMA, pxIndex * 2);
                        while (!ST7789_SPI_Ready);
                        pxIndex = 0;
                    }
                }
            }
        }
    }

    if (pxIndex > 0)
    {
        ST7789_SendData_DMA(BufferDMA, pxIndex * 2);
        while (!ST7789_SPI_Ready);
    }
}

//Функция вывода строки двухбайтовым шрифтом
void ST7789_DrawStringTwoByteFonts(uint16_t xPos, uint16_t yPos, char *str, uint16_t colorCh, uint16_t colorBk, uint8_t scale)
{
    for (int i = 0; str[i] != '\0'; i++)
	{
    	if(!UseDMA)
    	{
    		ST7789_DrawCharTwoByteFonts(xPos, yPos, str[i], colorCh, colorBk, scale);
    	}
    	else if(UseDMA)
    	{
			ST7789_DrawCharTwoByteFonts_DMA(xPos, yPos, str[i], colorCh, colorBk, scale);
		}
        xPos += (10 * scale);
    }
}
