/*
 *
 * st7789_demo.c
 *
 * Created:		08.03.2025 20:05:29
 * Author:		HTTPS://R9OFG.RU
 *
 * Modified:	хх.хх.хххх
 *
 */

#include "main.h"

extern volatile uint8_t UseDMA;

//Функция вывода строки однобайтовым шрифтом
void ST7789_DrawStringOneByteFontRotation()
{
	ST7789_SetRotation(ST7789_ROTATE_0);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringOneByteFonts(10, 10, "Hello!", WHITE, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 32, "I'm display", WHITE, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 54, "ST7789", WHITE, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 76, "170х320", WHITE, BLACK, X2);
	HAL_Delay(PAUSE);
	
	ST7789_SetRotation(ST7789_ROTATE_90);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringOneByteFonts(10, 10, "Hello!", RED, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 32, "I'm display", RED, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 54, "ST7789", RED, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 76, "170х320", RED, BLACK, X2);
	HAL_Delay(PAUSE);
	
	ST7789_SetRotation(ST7789_ROTATE_180);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringOneByteFonts(10, 10, "Hello!", GREEN, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 32, "I'm display", GREEN, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 54, "ST7789", GREEN, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 76, "170х320", GREEN, BLACK, X2);
	HAL_Delay(PAUSE);
	
	ST7789_SetRotation(ST7789_ROTATE_270);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringOneByteFonts(10, 10, "Hello!", BLUE, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 32, "I'm display", BLUE, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 54, "ST7789", BLUE, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 76, "170х320", BLUE, BLACK, X2);
	HAL_Delay(PAUSE);
	
	ST7789_SetRotation(ST7789_ROTATE_0);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringOneByteFonts(10, 10, "Font 8x10 x1", WHITE, BLACK, X1);
	ST7789_DrawStringOneByteFonts(10, 22, "Font 8x10 x2", WHITE, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 44, "Font x3", WHITE, BLACK, X3);

	ST7789_DrawStringOneByteFonts(10, 100, "Font 8x10 x1", RED, WHITE, X1);
	ST7789_DrawStringOneByteFonts(10, 112, "Font 8x10 x2", RED, WHITE, X2);
	ST7789_DrawStringOneByteFonts(10, 134, "Font x3", RED, WHITE, X3);
	HAL_Delay(PAUSE);

	ST7789_SetRotation(ST7789_ROTATE_90);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringOneByteFonts(10, 10, "Font 8x10 x1", WHITE, BLACK, X1);
	ST7789_DrawStringOneByteFonts(10, 22, "Font 8x10 x2", WHITE, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 44, "Font 8x10 x3", WHITE, BLACK, X3);

	ST7789_DrawStringOneByteFonts(10, 100, "Font 8x10 x1", RED, WHITE, X1);
	ST7789_DrawStringOneByteFonts(10, 112, "Font 8x10 x2", RED, WHITE, X2);
	ST7789_DrawStringOneByteFonts(10, 134, "Font 8x10 x3", RED, WHITE, X3);
	HAL_Delay(PAUSE);

	ST7789_SetRotation(ST7789_ROTATE_180);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringOneByteFonts(10, 10, "Font 8x10 x1", WHITE, BLACK, X1);
	ST7789_DrawStringOneByteFonts(10, 22, "Font 8x10 x2", WHITE, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 44, "Font x3", WHITE, BLACK, X3);

	ST7789_DrawStringOneByteFonts(10, 100, "Font 8x10 x1", RED, WHITE, X1);
	ST7789_DrawStringOneByteFonts(10, 112, "Font 8x10 x2", RED, WHITE, X2);
	ST7789_DrawStringOneByteFonts(10, 134, "Font x3", RED, WHITE, X3);
	HAL_Delay(PAUSE);

	ST7789_SetRotation(ST7789_ROTATE_270);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringOneByteFonts(10, 10, "Font 8x10 x1", WHITE, BLACK, X1);
	ST7789_DrawStringOneByteFonts(10, 22, "Font 8x10 x2", WHITE, BLACK, X2);
	ST7789_DrawStringOneByteFonts(10, 44, "Font 8x10 x3", WHITE, BLACK, X3);
	
	ST7789_DrawStringOneByteFonts(10, 100, "Font 8x10 x1", RED, WHITE, X1);
	ST7789_DrawStringOneByteFonts(10, 112, "Font 8x10 x2", RED, WHITE, X2);
	ST7789_DrawStringOneByteFonts(10, 134, "Font 8x10 x3", RED, WHITE, X3);
	HAL_Delay(PAUSE);
}

//Функция вывода строки двухбайтовым шрифтом
void ST7789_DrawStringTwoByteFontRotation()
{
	ST7789_SetRotation(ST7789_ROTATE_0);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringTwoByteFonts(10, 10, "0123456789", WHITE, BLACK, X1);
	ST7789_DrawStringTwoByteFonts(10, 27, "0123456", WHITE, BLACK, X2);
	ST7789_DrawStringTwoByteFonts(10, 59, "01234", WHITE, BLACK, X3);
	HAL_Delay(PAUSE);

	ST7789_SetRotation(ST7789_ROTATE_90);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringTwoByteFonts(10, 10, "0123456789", WHITE, BLACK, X1);
	ST7789_DrawStringTwoByteFonts(10, 27, "0123456789", WHITE, BLACK, X2);
	ST7789_DrawStringTwoByteFonts(10, 59, "012345678", WHITE, BLACK, X3);
	HAL_Delay(PAUSE);
	
	ST7789_SetRotation(ST7789_ROTATE_180);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringTwoByteFonts(10, 10, "0123456789", WHITE, BLACK, X1);
	ST7789_DrawStringTwoByteFonts(10, 27, "0123456", WHITE, BLACK, X2);
	ST7789_DrawStringTwoByteFonts(10, 59, "01234", WHITE, BLACK, X3);
	HAL_Delay(PAUSE);

	ST7789_SetRotation(ST7789_ROTATE_270);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringTwoByteFonts(10, 10, "0123456789", WHITE, BLACK, X1);
	ST7789_DrawStringTwoByteFonts(10, 27, "0123456789", WHITE, BLACK, X2);
	ST7789_DrawStringTwoByteFonts(10, 59, "012345678", WHITE, BLACK, X3);
	HAL_Delay(PAUSE);

	ST7789_SetRotation(ST7789_ROTATE_0);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringTwoByteFonts(10, 10, "0123456789", LIME, DARKGREEN, X1);
	ST7789_DrawStringTwoByteFonts(10, 27, "0123456", LIME, DARKGREEN, X2);
	ST7789_DrawStringTwoByteFonts(10, 59, "01234", LIME, DARKGREEN, X3);
	HAL_Delay(PAUSE);

	ST7789_SetRotation(ST7789_ROTATE_90);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringTwoByteFonts(10, 10, "0123456789", LIME, DARKGREEN, X1);
	ST7789_DrawStringTwoByteFonts(10, 27, "0123456789", LIME, DARKGREEN, X2);
	ST7789_DrawStringTwoByteFonts(10, 59, "012345678", LIME, DARKGREEN, X3);
	HAL_Delay(PAUSE);

	ST7789_SetRotation(ST7789_ROTATE_180);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringTwoByteFonts(10, 10, "0123456789", LIME, DARKGREEN, X1);
	ST7789_DrawStringTwoByteFonts(10, 27, "0123456", LIME, DARKGREEN, X2);
	ST7789_DrawStringTwoByteFonts(10, 59, "01234", LIME, DARKGREEN, X3);
	HAL_Delay(PAUSE);

	ST7789_SetRotation(ST7789_ROTATE_270);
	ST7789_FillScreen(BLACK, ST7789_FULL_PIXEL);
	ST7789_DrawStringTwoByteFonts(10, 10, "0123456789", LIME, DARKGREEN, X1);
	ST7789_DrawStringTwoByteFonts(10, 27, "0123456789", LIME, DARKGREEN, X2);
	ST7789_DrawStringTwoByteFonts(10, 59, "012345678", LIME, DARKGREEN, X3);
	HAL_Delay(PAUSE);
}

//Функция заливки дисплея разными цветами с разной ориентацией
void ST7789_FillScreenColorRotation()
{
	//Поворот на 0 градусов
	ST7789_SetRotation(ST7789_ROTATE_0);
	ST7789_FillScreen(BLACK,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(WHITE,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(RED,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(GREEN,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(BLUE,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	
	//Поворот на 90 градусов
	ST7789_SetRotation(ST7789_ROTATE_90);
	ST7789_FillScreen(BLACK,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(WHITE,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(RED,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(GREEN,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(BLUE,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	
	//Поворот на 180 градусов
	ST7789_SetRotation(ST7789_ROTATE_180);
	ST7789_FillScreen(BLACK,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(WHITE,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(RED,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(GREEN,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(BLUE,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	
	//Поворот на 270 градусов
	ST7789_SetRotation(ST7789_ROTATE_270);
	ST7789_FillScreen(BLACK,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(WHITE,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(RED,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(GREEN,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
	ST7789_FillScreen(BLUE,ST7789_FULL_PIXEL);
	HAL_Delay(TEST_DELAY);
}

//Функция вывода рандомных разноцветных линий
void ST7789_DrawRandomLine()
{
	//Генерация случайного цвета (RGB565)
	uint16_t r = rand() % 32;					//5 бит для красного (0–31)
	uint16_t g = rand() % 64;					//6 бит для зелёного (0–63)
	uint16_t b = rand() % 32;					//5 бит для синего (0–31)
	uint16_t color = (r << 11) | (g << 5) | b;
	
	//Генерация случайных координат для начальной и конечной точек
	uint16_t x0 = rand() % CurrentWidth;		//Случайная координата X для начальной точки
	uint16_t y0 = rand() % CurrentHeight;		//Случайная координата Y для начальной точки
	uint16_t x1 = rand() % CurrentWidth;		//Случайная координата X для конечной точки
	uint16_t y1 = rand() % CurrentHeight;		//Случайная координата Y для конечной точки

	//Рисуем линию
	ST7789_DrawLine(x0, y0, x1, y1, color);
}

//Функция вывода рандомных пустотелых прямоугольников
void ST7789_DrawRandomRectangle()
{
	//Генерация случайного цвета (RGB565)
	uint16_t r = rand() % 32;					//5 бит для красного (0–31)
	uint16_t g = rand() % 64;					//6 бит для зелёного (0–63)
	uint16_t b = rand() % 32;					//5 бит для синего (0–31)
	uint16_t color = (r << 11) | (g << 5) | b;
		
	//Генерация случайных координат для начальной и конечной точек
	uint16_t x0 = rand() % CurrentWidth;		//Случайная координата X для начальной точки
	uint16_t y0 = rand() % CurrentHeight;		//Случайная координата Y для начальной точки
	uint16_t x1 = rand() % CurrentWidth;		//Случайная координата X для конечной точки
	uint16_t y1 = rand() % CurrentHeight;		//Случайная координата Y для конечной точки

	ST7789_DrawRectangle(x0, y0, x1, y1, color);
}

//Функция вывода рандомных закрашенных прямоугольников
void ST7789_DrawRandomFillRectangle()
{
	//Генерация случайного цвета (RGB565)
	uint16_t r = rand() % 32;					//5 бит для красного (0–31)
	uint16_t g = rand() % 64;					//6 бит для зелёного (0–63)
	uint16_t b = rand() % 32;					//5 бит для синего (0–31)
	uint16_t color = (r << 11) | (g << 5) | b;
	
	//Генерация случайных координат для начальной и конечной точек
	uint16_t x0 = rand() % CurrentWidth;		//Случайная координата X для начальной точки
	uint16_t y0 = rand() % CurrentHeight;		//Случайная координата Y для начальной точки
	uint16_t x1 = rand() % CurrentWidth;		//Случайная координата X для конечной точки
	uint16_t y1 = rand() % CurrentHeight;		//Случайная координата Y для конечной точки

	ST7789_DrawFillRectangle(x0, y0, x1, y1, color);
}

//Функция вывода рандомных пустотелых кругов
void ST7789_DrawRandomCircle()
{
	//Генерация случайного цвета (RGB565)
	uint16_t r = rand() % 32;					//5 бит для красного (0–31)
	uint16_t g = rand() % 64;					//6 бит для зелёного (0–63)
	uint16_t b = rand() % 32;					//5 бит для синего (0–31)
	uint16_t color = (r << 11) | (g << 5) | b;
	
	//Генерация случайных координат для центра и радиуса
	uint16_t x = rand() % CurrentWidth;			//Случайная координата X для начальной точки
	uint16_t y = rand() % CurrentHeight;		//Случайная координата Y для начальной точки
	uint16_t rad = rand() % CurrentWidth / 4;	//Случайная координата X для конечной точки

	ST7789_DrawCircle(x, y, rad, color);
}

//Функция вывода рандомных закрашеных кругов
void ST7789_DrawRandomFillCircle()
{
	//Генерация случайного цвета (RGB565)
	uint16_t r = rand() % 32;					//5 бит для красного (0–31)
	uint16_t g = rand() % 64;					//6 бит для зелёного (0–63)
	uint16_t b = rand() % 32;					//5 бит для синего (0–31)
	uint16_t color = (r << 11) | (g << 5) | b;
	
	//Генерация случайных координат для центра и радиуса
	uint16_t x = rand() % CurrentWidth;			//Случайная координата X для начальной точки
	uint16_t y = rand() % CurrentHeight;		//Случайная координата Y для начальной точки
	uint16_t rad = rand() % CurrentWidth / 4;	//Случайная координата X для конечной точки

	if(!UseDMA)
	{
		ST7789_DrawFillCircle(x, y, rad, color);
	}
	else if(UseDMA)
	{
		ST7789_DrawFillCircle_DMA(x, y, rad, color);
	}
}

