/*
 * st7789.h
 *
 * For 170*320 display module
 *
 * Created:		09.04.2025
 * Author:		HTTPS://R9OFG.RU
 *
 * Release:		1.1
 *
 * Modified:	15.04.2025
 *
 */ 

#ifndef ST7789_H_
#define ST7789_H_

#include "main.h"

//Определения пинов для STM32
#define ST7789_CS_PIN       	CS_PIN_Pin
#define ST7789_DC_PIN       	DC_PIN_Pin
#define ST7789_RST_PIN      	RST_PIN_Pin
#define ST7789_BLK_PIN      	BLK_PIN_Pin
#define ST7789_GPIO_PORT    	GPIOA

//Макросы управления пинами через BSRR
#define ST7789_CS_LOW()     	(ST7789_GPIO_PORT->BSRR = (ST7789_CS_PIN << 16))   //Сброс CS (0)
#define ST7789_CS_HIGH()    	(ST7789_GPIO_PORT->BSRR = ST7789_CS_PIN)           //Установка CS (1)
#define ST7789_DC_LOW()     	(ST7789_GPIO_PORT->BSRR = (ST7789_DC_PIN << 16))   //Сброс DC (0)
#define ST7789_DC_HIGH()    	(ST7789_GPIO_PORT->BSRR = ST7789_DC_PIN)           //Установка DC (1)
#define ST7789_RST_LOW()    	(ST7789_GPIO_PORT->BSRR = (ST7789_RST_PIN << 16))  //Сброс RST (0)
#define ST7789_RST_HIGH()   	(ST7789_GPIO_PORT->BSRR = ST7789_RST_PIN)          //Установка RST (1)
#define BLK_OFF()    			(ST7789_GPIO_PORT->BSRR = (ST7789_BLK_PIN << 16))  //Сброс BLK (0)
#define BLK_ON()				(ST7789_GPIO_PORT->BSRR = ST7789_BLK_PIN)          //Установка BLK (1)

//Команды ST7789
#define ST7789_NOP              0x00
#define ST7789_SWRESET          0x01
#define ST7789_SLPIN            0x10
#define ST7789_SLPOUT           0x11
#define ST7789_COLMOD           0x3A
#define ST7789_MADCTL           0x36
#define ST7789_CASET            0x2A
#define ST7789_RASET            0x2B
#define ST7789_RAMWR            0x2C
#define ST7789_DISPON           0x29
#define ST7789_DISPOFF          0x28
#define ST7789_INVON            0x21
#define ST7789_INVOFF           0x20

//Определение области дисплея и ориентации
#define ST7789_WIDTH            170
#define ST7789_HEIGHT           320UL
#define ST7789_FULL_PIXEL       (ST7789_WIDTH * ST7789_HEIGHT)
#define ST7789_RGB              0x00
#define ST7789_BGR              0x08
#define ST7789_ROTATE_0         0x00
#define ST7789_ROTATE_90        0x60
#define ST7789_ROTATE_180       0xC0
#define ST7789_ROTATE_270       0xA0

//Определение цветов в формате RGB565
#define BLACK                   0x0000
#define WHITE                   0xFFFF
#define RED                     0xF800
#define GREEN                   0x07E0
#define BLUE                    0x001F
#define LIME                    0x07E0
#define DARKGREEN               0x03E0
#define YELLOW                  0xFFE0
#define GREY                    0x2A69
#define SILVER                  0xBDF7

//Определение масштабов увеличения шрифта
#define X1						1		//стандартный рамер шрифта
#define X2						2		//множитель 2
#define X3						3		//множитель 3

//Глобальные переменные
extern uint16_t CurrentWidth;
extern uint16_t CurrentHeight;

extern SPI_HandleTypeDef hspi1;				//указатель на spi
extern volatile uint8_t ST7789_SPI_Ready;	//флаг окончания передачи DMA

//Прототипы функций
void ST7789_SendCommand(uint8_t command);
void ST7789_SendData(uint8_t data);
void ST7789_SetRotation(char rotation);
void ST7789_SetRegion(uint16_t x, uint16_t y, uint16_t width, uint16_t height);
void ST7789_FillScreen(uint16_t color, uint16_t cntPxl);
void ST7789_Init();
void ST7789_DrawPixel(uint16_t x, uint16_t y, uint16_t color);
void ST7789_DrawLine(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint16_t color);
void ST7789_DrawRectangle(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint16_t color);
void ST7789_DrawFillRectangle(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint16_t color);
void ST7789_DrawCircle(uint16_t x, uint16_t y, uint16_t radius, uint16_t color);
void ST7789_DrawFillCircle(uint16_t x, uint16_t y, uint16_t radius, uint16_t color);
void ST7789_DrawFillCircle_DMA(uint16_t x, uint16_t y, uint16_t radius, uint16_t color);

void ST7789_DrawCharOneByteFonts(uint16_t xPos, uint16_t yPos, char sym, uint16_t colorCh, uint16_t colorBk, uint8_t scale);
void ST7789_DrawCharOneByteFonts_DMA(uint16_t xPos, uint16_t yPos, char sym, uint16_t colorCh, uint16_t colorBk, uint8_t scale);
void ST7789_DrawStringOneByteFonts(uint16_t xPos, uint16_t yPos, char *str, uint16_t colorCh, uint16_t colorBk, uint8_t scale);

void ST7789_DrawCharTwoByteFonts(uint16_t xPos, uint16_t yPos, char sym, uint16_t colorCh, uint16_t colorBk, uint8_t scale);
void ST7789_DrawCharTwoByteFonts_DMA(uint16_t xPos, uint16_t yPos, char sym, uint16_t colorCh, uint16_t colorBk, uint8_t scale);
void ST7789_DrawStringTwoByteFonts(uint16_t xPos, uint16_t yPos, char *str, uint16_t colorCh, uint16_t colorBk, uint8_t scale);

#endif /* ST7789_H_ */
