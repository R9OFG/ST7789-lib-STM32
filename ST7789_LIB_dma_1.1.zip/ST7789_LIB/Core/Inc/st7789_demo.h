﻿/*
 *
 * st7789_demo.h
 *
 * Created:		08.03.2025 20:05:29
 * Author:		HTTPS://R9OFG.RU
 *
 * Modified:	хх.хх.хххх
 *
 */

#include "main.h"

#ifndef ST7789_DEMO_H_
#define ST7789_DEMO_H_

#define PAUSE		2000
#define TEST_DELAY	500

void ST7789_DrawStringOneByteFontRotation();
void ST7789_DrawStringTwoByteFontRotation();
void ST7789_FillScreenColorRotation();
void ST7789_DrawRandomLine();
void ST7789_DrawRandomRectangle();
void ST7789_DrawRandomFillRectangle();
void ST7789_DrawRandomCircle();
void ST7789_DrawRandomFillCircle();

#endif /* ST7789_DEMO_H_ */
